// Derived from the same definitions consumed by Paper.
bool duiMapDefinition(int m,out vec2 size,out float pixels,out float minimum,out float step,out vec4 opening,out int easing){
return false;}
bool duiMapLayer(int m,int i,out vec4 rect,out int space,out float depth,out vec3 alpha){
return false;}
