#version 330

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:sample_lightmap.glsl>
#endif

#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
in ivec2 UV2;
#endif

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
uniform sampler2D Sampler2;
out float sphericalVertexDistance;
out float cylindricalVertexDistance;
#endif

out vec4 vertexColor;
out vec2 texCoord0;

#ifdef IS_GUI
uniform sampler2D Sampler0;
flat out int ramHud;
out vec2 ramHudPoint;
const vec2 RAM_HUD_SIZE = vec2(133.0, 20.0);
const vec2 RAM_HUD_AT = vec2(4.0, 4.0);
const vec2 RAM_HUD_SPIN = vec2(10.0, 10.0);
const vec3 RAM_HUD_GREEN = vec3(0.3333, 1.0000, 0.3333);

// RaiseAMob updating indicator (RaiseAMob-Status): a font picture whose corner pixels carry the
// marker (alpha 247, red 82, green 65, blue 224 + corner) is drawn in the top-left corner instead.
bool ramHudVertex() {
    ivec2 texSize = textureSize(Sampler0, 0);
    vec4 marker = texelFetch(Sampler0, clamp(ivec2(UV0 * vec2(texSize)), ivec2(0), texSize - 1), 0);
    uvec4 d = uvec4(round(marker * 255.0));
    int corner = int(d.b) - 224;
    if (d.a != 247u || d.r != 82u || d.g != 65u || corner < 0 || corner > 3) return false;
    vec2 c = vec2(float(corner & 1), float((corner >> 1) & 1));
    ramHud = 1;
    ramHudPoint = c * RAM_HUD_SIZE;
    gl_Position = ProjMat * ModelViewMat * vec4(RAM_HUD_AT + ramHudPoint, Position.z, 1.0);
    vertexColor = Color;
    texCoord0 = UV0;
    return true;
}
#endif

void main() {
#ifdef IS_GUI
    ramHud = 0;
    ramHudPoint = vec2(0.0);
    if (ramHudVertex()) return;
#endif
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    vertexColor = Color * sample_lightmap(Sampler2, UV2);
#else
    vertexColor = Color;
#endif
    texCoord0 = UV0;
}
