#version 330

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#moj_import <minecraft:fog.glsl>
#endif

#moj_import <minecraft:dynamictransforms.glsl>

uniform sampler2D Sampler0;

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
in float sphericalVertexDistance;
in float cylindricalVertexDistance;
#endif

in vec4 vertexColor;
in vec2 texCoord0;

out vec4 fragColor;

#ifdef IS_GUI
#moj_import <minecraft:globals.glsl>
flat in int ramHud;
in vec2 ramHudPoint;
const vec2 RAM_HUD_SIZE = vec2(133.0, 20.0);
const vec2 RAM_HUD_AT = vec2(4.0, 4.0);
const vec2 RAM_HUD_SPIN = vec2(10.0, 10.0);
const vec3 RAM_HUD_GREEN = vec3(0.3333, 1.0000, 0.3333);

// RaiseAMob updating indicator: dark rounded panel, 12-spoke spinner turning once a second, label.
vec4 ramHudColor(vec2 p, vec2 uv, float seconds) {
    float aa = max(fwidth(p.x), 0.0001);
    vec2 q = abs(p - RAM_HUD_SIZE * 0.5) - (RAM_HUD_SIZE * 0.5 - 4.0);
    float d = length(max(q, 0.0)) + min(max(q.x, q.y), 0.0) - 4.0;
    float inside = clamp(0.5 - d / aa, 0.0, 1.0);
    if (inside <= 0.0) return vec4(0.0);
    vec3 col = vec3(0.07, 0.075, 0.085);
    float outline = clamp(0.5 - abs(d + 0.5) / aa, 0.0, 1.0);
    col = mix(col, vec3(0.30, 0.32, 0.35), outline * 0.7);
    float alpha = 0.86;

    vec2 v = p - RAM_HUD_SPIN;
    float step30 = 3.14159265 / 6.0;
    float ang = atan(v.x, -v.y);
    float k = mod(floor(ang / step30 + 0.5), 12.0);
    float th = k * step30;
    vec2 dir = vec2(sin(th), -cos(th));
    float along = dot(v, dir);
    float across = dot(v, vec2(cos(th), sin(th)));
    float dist = length(vec2(across, along - clamp(along, 3.2, 6.4))) - 0.85;
    float spoke = clamp(0.5 - dist / aa, 0.0, 1.0);
    float head = floor(fract(seconds) * 12.0);
    float age = mod(head - k, 12.0);
    float bright = mix(1.0, 0.18, age / 11.0);
    col = mix(col, RAM_HUD_GREEN, spoke * bright);
    alpha = max(alpha, spoke * bright);

    vec4 t = texture(Sampler0, uv);
    if (abs(t.a * 255.0 - 247.0) > 0.5) {
        col = mix(col, t.rgb, t.a);
        alpha = max(alpha, t.a);
    }
    return vec4(col, alpha * inside);
}
#endif

void main() {
#ifdef IS_GUI
    if (ramHud == 1) {
        vec4 hud = ramHudColor(ramHudPoint, texCoord0, GameTime * 1200.0);
        if (hud.a < 0.004) discard;
        fragColor = hud;
        return;
    }
#endif
#ifdef IS_GRAYSCALE
    vec4 texColor = texture(Sampler0, texCoord0).rrrr;
#else
    vec4 texColor = texture(Sampler0, texCoord0);
#endif

#ifdef IS_SEE_THROUGH
    vec4 color = texColor * vertexColor;
#else
    vec4 color = texColor * vertexColor * ColorModulator;
#endif
    if (color.a < 0.1) {
        discard;
    }

#ifdef IS_SEE_THROUGH
    fragColor = color * ColorModulator;
#elif defined(IS_GUI)
    fragColor = color;
#else
    fragColor = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, FogColor);
#endif
}
