#version 330

// Can't moj_import in things used during startup, when resource packs don't exist.
// This is a copy of dynamicimports.glsl
layout(std140) uniform DynamicTransforms {
    mat4 ModelViewMat;
    vec4 ColorModulator;
    vec3 ModelOffset;
    mat4 TextureMat;
};

uniform sampler2D Sampler0;

in vec2 texCoord0;
in vec4 vertexColor;

out vec4 fragColor;

layout(std140) uniform Globals {
    ivec3 CameraBlockPos;
    vec3 CameraOffset;
    vec2 ScreenSize;
    float GlintAlpha;
    float GameTime;
    int MenuBlurRadius;
    int UseRgss;
};

// RaiseAMob's menu sky: the store website's background (store.raiseamob.net, raiseamob.css #ramSky),
// drawn over the whole screen behind in-game menus and dialogs. The pack's inworld_menu_background.png
// is filled with a marker colour; where the menu shader samples it, this paints the sky instead.
// Needs Globals (GameTime, ScreenSize). GameTime * 1200 is seconds and wraps every 20 minutes, so
// every motion's period divides 1200 s and the sky never jumps.

const float RAM_SKY_ALPHA = 0.88;  // the world shows faintly through

bool ramSkyMarker(vec4 tex) {
    ivec4 m = ivec4(round(tex * 255.0));
    return m == ivec4(82, 65, 199, 241);
}

float ramHash(vec2 p) {
    return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453);
}

vec3 ramMix(vec3 base, vec3 glow, float a) {
    return mix(base, glow, clamp(a, 0.0, 1.0));
}

// A glow: radial-gradient(closest-side, colour a, transparent) softened by the site's 40px blur. Its
// box is a share of the screen's width and height, so in screen fractions it is a circle.
float ramGlow(vec2 p, vec2 centre, float radius) {
    float r = length(p - centre) / radius;
    return pow(clamp(1.0 - r, 0.0, 1.0), 1.25);
}

vec4 ramSky(vec2 fragCoord) {
    float seconds = GameTime * 1200.0;
    vec2 p = fragCoord / ScreenSize;
    p.y = 1.0 - p.y;  // 0 at the top of the screen

    // linear-gradient(160deg, #150c3a 0%, #0c1f4a 35%, #08343f 65%, #0b2a1c 100%)
    vec2 dir = vec2(0.342, 0.940);
    float t = clamp(dot(p - 0.5, dir) / (0.5 * (abs(dir.x) + abs(dir.y))) * 0.5 + 0.5, 0.0, 1.0);
    vec3 c0 = vec3(0x15, 0x0C, 0x3A) / 255.0, c1 = vec3(0x0C, 0x1F, 0x4A) / 255.0;
    vec3 c2 = vec3(0x08, 0x34, 0x3F) / 255.0, c3 = vec3(0x0B, 0x2A, 0x1C) / 255.0;
    vec3 col = t < 0.35 ? mix(c0, c1, t / 0.35) : t < 0.65 ? mix(c1, c2, (t - 0.35) / 0.3) : mix(c2, c3, (t - 0.65) / 0.35);
    // radial-gradient(120% 70% at 50% 0%, rgb(54 32 140 / 55%), transparent 70%)
    float haze = length(vec2((p.x - 0.5) / 1.2, p.y / 0.7));
    col = ramMix(col, vec3(54.0, 32.0, 140.0) / 255.0, 0.55 * clamp(1.0 - haze / 0.7, 0.0, 1.0));

    // The glows drift, turn and swell together, there and back every 75 s (the site: 38 s alternate).
    float w = 6.2831853 * seconds / 75.0;
    float s = sin(w);
    float angle = radians(8.0) * s;
    vec2 q = p - 0.5;
    q = mat2(cos(angle), -sin(angle), sin(angle), cos(angle)) * q / (1.0 + 0.03 * (1.0 - cos(w)));
    q -= vec2(0.03, -0.02) * s;
    vec2 g = q + 0.5;
    col = ramMix(col, vec3(0xCC, 0x40, 0xFF) / 255.0, 0.75 * ramGlow(g, vec2(0.27, 0.29), 0.40));
    col = ramMix(col, vec3(0x5E, 0xE6, 0xD0) / 255.0, 0.62 * ramGlow(g, vec2(0.78, 0.24), 0.36));
    col = ramMix(col, vec3(0x3A, 0x7B, 0xFF) / 255.0, 0.68 * ramGlow(g, vec2(0.73, 0.73), 0.40));
    col = ramMix(col, vec3(0x57, 0xD8, 0x62) / 255.0, 0.52 * ramGlow(g, vec2(0.24, 0.76), 0.36));
    col = ramMix(col, vec3(0xFF, 0x5C, 0xAA) / 255.0, 0.28 * ramGlow(g, vec2(0.50, 0.50), 0.42));

    // Sparkles: about one in 64 x 64 GUI-ish units, drifting up 25 cells every 20 minutes and
    // twinkling every 12 s, each at its own phase.
    float unit = ScreenSize.y / 360.0;
    vec2 u = vec2(fragCoord.x, ScreenSize.y - fragCoord.y) / unit;
    u.y += seconds * (25.0 * 64.0 / 1200.0);
    vec2 cell = floor(u / 64.0);
    cell.y = mod(cell.y, 25.0);
    float h = ramHash(cell);
    if (h > 0.4) {
        vec2 spot = (vec2(ramHash(cell + 7.1), ramHash(cell + 3.3)) * 0.8 + 0.1) * 64.0;
        vec2 local = mod(u, 64.0);
        float size = h > 0.85 ? 1.6 : 1.1;
        float spark = clamp(size - length(local - spot), 0.0, 1.0);
        float twinkle = 0.35 + 0.4 * (0.5 + 0.5 * sin(6.2831853 * (seconds / 12.0 + h * 7.0)));
        vec3 sparkle = h > 0.8 ? vec3(1.0) : h > 0.6 ? vec3(0xBF, 0xF5, 0xEA) / 255.0 : vec3(0xF3, 0xC6, 0xFF) / 255.0;
        col = ramMix(col, sparkle, spark * twinkle);
    }
    return vec4(col, RAM_SKY_ALPHA);
}

void main() {
    vec4 ramTex = texture(Sampler0, texCoord0);
    if (ramSkyMarker(ramTex)) {
        vec4 sky = ramSky(gl_FragCoord.xy);
        fragColor = vec4(sky.rgb, sky.a * vertexColor.a) * ColorModulator;
        return;
    }
    vec4 color = ramTex * vertexColor;
    if (color.a == 0.0) {
        discard;
    }
    fragColor = color * ColorModulator;
}
