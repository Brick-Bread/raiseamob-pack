#version 330

// Can't moj_import in things used during startup, when resource packs don't exist.
// This is a copy of dynamicimports.glsl
layout(std140) uniform DynamicTransforms {
    mat4 ModelViewMat;
    vec4 ColorModulator;
    vec3 ModelOffset;
    mat4 TextureMat;
};

in vec4 vertexColor;
noperspective in vec2 dialogQuadUV;
noperspective in vec2 dialogGuiPosition;

out vec4 fragColor;

void main() {
    vec4 color = vertexColor;
    // Compute quad dimensions in GUI units, independent of physical resolution and GUI scale.
    mat2 uvDerivatives = mat2(dFdx(dialogQuadUV), dFdy(dialogQuadUV));
    mat2 positionDerivatives = mat2(dFdx(dialogGuiPosition), dFdy(dialogGuiPosition));
    float uvDeterminant = determinant(uvDerivatives);
    vec2 extent = vec2(0.0);
    if (abs(uvDeterminant) > 1e-12) {
        mat2 axes = positionDerivatives * inverse(uvDerivatives);
        extent = vec2(length(axes[0]), length(axes[1]));
    }
    bool onePixelStroke = abs(min(extent.x, extent.y) - 1.0) < 0.001
                       && max(extent.x, extent.y) >= 9.999;
    bool flatColor = length(dFdx(vertexColor)) + length(dFdy(vertexColor)) < 0.00001;
    bool opaqueWhite = all(greaterThan(color.rgb, vec3(0.999))) && color.a > 0.999;
    if (onePixelStroke && flatColor && opaqueWhite) {
        discard;
    }
    if (color.a == 0.0) {
        discard;
    }
    fragColor = color * ColorModulator;
}
