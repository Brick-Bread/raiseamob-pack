#version 330

// Can't moj_import in things used during startup, when resource packs don't exist.
// This is a copy of dynamicimports.glsl and projection.glsl
layout(std140) uniform DynamicTransforms {
    mat4 ModelViewMat;
    vec4 ColorModulator;
    vec3 ModelOffset;
    mat4 TextureMat;
};
layout(std140) uniform Projection {
    mat4 ProjMat;
};

in vec3 Position;
in vec4 Color;

out vec4 vertexColor;
noperspective out vec2 dialogQuadUV;
noperspective out vec2 dialogGuiPosition;

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

    vertexColor = Color;
    // ColoredRectangleRenderState order: top-left, bottom-left, bottom-right, top-right.
    // Minecraft submits GUI geometry as four-vertex indexed quads.
    int corner = gl_VertexID & 3;
    dialogQuadUV = vec2(corner >= 2 ? 1.0 : 0.0,
                        corner == 1 || corner == 2 ? 1.0 : 0.0);
    dialogGuiPosition = Position.xy;
}
