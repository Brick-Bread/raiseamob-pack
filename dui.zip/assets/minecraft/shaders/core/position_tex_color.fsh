#version 330
#extension GL_ARB_separate_shader_objects : require

// Can't moj_import in things used during startup, when resource packs don't exist.
// This is a copy of dynamicimports.glsl
layout(std140) uniform DynamicTransforms {
    mat4 ModelViewMat;
    mat4 TextureMat;
    vec4 ColorModulator;
    vec3 ModelOffset;
};

layout(std140) uniform Globals {
    ivec3 CameraBlockPos;
    float GlintAlpha;
    vec3 CameraOffset;
    float GameTime;
    vec2 ScreenSize;
    int MenuBlurRadius;
    int UseRgss;
};
uniform sampler2D Sampler0;

layout(location = 5) in vec2 clipPoint;
layout(location = 6) flat in vec4 itemClip;
layout(location = 0) in vec2 texCoord0;
layout(location = 1) in vec4 vertexColor;
layout(location = 7) in vec2 burstPoint;
layout(location = 8) flat in vec2 burstBounds;
layout(location = 9) flat in vec3 burstItem;
layout(location = 10) flat in float burstAge;
layout(location = 11) flat in int effectKind;
layout(location = 12) flat in int effectFlags;
layout(location = 13) flat in int effectCount;
layout(location = 14) flat in uvec4 effectWords[5];

layout(location = 2) flat in int playerArmorFlags;
layout(location = 3) in vec2 playerArmorPoint;
layout(location = 4) flat in vec2 playerArmorSize;
#include <dui:player-renderers.glsl>
// Shared orthographic cuboid renderer. Skin UVs use Minecraft's normalized 64x64 layout.
mat3 playerYaw(float a){float c=cos(a),s=sin(a);return mat3(c,0,-s,0,1,0,s,0,c);}
mat3 playerPitch(float a){float c=cos(a),s=sin(a);return mat3(1,0,0,0,c,s,0,-s,c);}
bool playerBox(vec3 ro,vec3 rd,vec3 halfSize,out float t,out vec3 normal,out vec3 point){
    vec3 safe=sign(rd)*max(abs(rd),vec3(.00001));safe=mix(vec3(.00001),safe,notEqual(rd,vec3(0)));
    vec3 a=(-halfSize-ro)/safe,b=(halfSize-ro)/safe;
    vec3 near=min(a,b),far=max(a,b);float enter=max(max(near.x,near.y),near.z),leave=min(min(far.x,far.y),far.z);
    if(leave<max(enter,0.0))return false;
    t=max(enter,0.0);point=ro+rd*t;
    normal=near.x>=near.y&&near.x>=near.z?vec3(-sign(rd.x),0,0):near.y>=near.z?vec3(0,-sign(rd.y),0):vec3(0,0,-sign(rd.z));return true;
}
vec2 playerUv(vec3 p,vec3 normal,vec3 dim,vec2 origin){
    vec3 f=p/dim+vec3(.5);float w=dim.x,h=dim.y,d=dim.z;
    if(normal.z>.5)return origin+vec2(d+f.x*w,d+(1.0-f.y)*h);
    if(normal.z<-.5)return origin+vec2(2.0*d+w+(1.0-f.x)*w,d+(1.0-f.y)*h);
    if(normal.x<-.5)return origin+vec2(f.z*d,d+(1.0-f.y)*h);
    if(normal.x>.5)return origin+vec2(d+w+(1.0-f.z)*d,d+(1.0-f.y)*h);
    if(normal.y>.5)return origin+vec2(d+f.x*w,(1.0-f.z)*d);
    return origin+vec2(d+w+f.x*w,f.z*d);
}
void playerPart(int i,bool slim,out vec3 center,out vec3 dim,out vec2 uv,out vec2 outer){
    if(i==0){center=vec3(0,28,0);dim=vec3(8);uv=vec2(0);outer=vec2(32,0);}
    else if(i==1){center=vec3(0,18,0);dim=vec3(8,12,4);uv=vec2(16,16);outer=vec2(16,32);}
    else if(i==2){center=vec3(slim?-5.5:-6.0,18,0);dim=vec3(slim?3:4,12,4);uv=vec2(40,16);outer=vec2(40,32);}
    else if(i==3){center=vec3(slim?5.5:6.0,18,0);dim=vec3(slim?3:4,12,4);uv=vec2(32,48);outer=vec2(48,48);}
    else if(i==4){center=vec3(-2,6,0);dim=vec3(4,12,4);uv=vec2(0,16);outer=vec2(0,32);}
    else{center=vec3(2,6,0);dim=vec3(4,12,4);uv=vec2(16,48);outer=vec2(0,48);}
}
void playerRay(vec2 q,vec2 size,int flags,out vec3 ro,out vec3 rd){
    vec4 view;vec2 idle;float limbs[6];if(!duiPlayerPose((flags>>10)&15,(flags>>2)&7,view,idle,limbs)){ro=vec3(0);rd=vec3(0,0,-1);return;}
    float scale=size.y/view.z;vec2 p=(q-size*.5)/scale;
    mat3 camera=playerYaw(view.x)*playerPitch(view.y);
    ro=camera*vec3(p.x,-p.y,60)+vec3(0,16,0);rd=camera*vec3(0,0,-1);
}
vec4 playerSkinPixel(sampler2D skin,vec2 q,vec2 size,int flags,float time){
    bool slim=(flags&32)!=0,outerLayer=(flags&64)!=0,idle=(flags&128)!=0;
    vec3 ro,rd;playerRay(q,size,flags,ro,rd);
    vec4 view;vec2 idleParams;float limbs[6];duiPlayerPose((flags>>10)&15,(flags>>2)&7,view,idleParams,limbs);
    float nearest=1e10;vec4 result=vec4(0);
    for(int i=0;i<6;i++){
        vec3 center,dim;vec2 uv,outer;playerPart(i,slim,center,dim,uv,outer);
        mat3 pose=playerPitch(limbs[i]+(idle&&i>=2&&i<=3?sin(time*idleParams.y)*idleParams.x*(i==2?1.0:-1.0):0.0));
        if(idle)center.y+=sin(time*idleParams.y)*.08;
        for(int layer=0;layer<2;layer++){
            if(layer==1&&!outerLayer)continue;
            vec3 expanded=dim+vec3(layer==1?(i==0?1.0:.5):0.0),n,p;float t;
            if(!playerBox(transpose(pose)*(ro-center),transpose(pose)*rd,expanded*.5,t,n,p)||t>=nearest)continue;
            vec2 tex=playerUv(p*dim/expanded,n,dim,layer==0?uv:outer);
            vec4 color=texelFetch(skin,ivec2(clamp(floor(tex),vec2(0),vec2(63))),0);
            if(color.a<.1)continue;
            nearest=t;float light=.65+.35*max(0.0,dot(pose*n,normalize(vec3(-.45,.8,1))));
            result=vec4(color.rgb*light,color.a);
        }
    }
    return result;
}
vec4 playerArmorPixel(sampler2D atlas,vec2 q,vec2 size,int flags,float time){
    bool slim=(flags&32)!=0,idle=(flags&128)!=0;int slot=(flags>>8)&3;
    vec3 ro,rd;playerRay(q,size,flags,ro,rd);
    vec4 view;vec2 idleParams;float limbs[6];duiPlayerPose((flags>>10)&15,(flags>>2)&7,view,idleParams,limbs);
    float nearest=1e10,bodyNearest=1e10;vec4 result=vec4(0);
    for(int i=0;i<6;i++){
        vec3 center,dim;vec2 uv,outer;playerPart(i,slim,center,dim,uv,outer);
        mat3 pose=playerPitch(limbs[i]+(idle&&i>=2&&i<=3?sin(time*idleParams.y)*idleParams.x*(i==2?1.0:-1.0):0.0));
        if(idle)center.y+=sin(time*idleParams.y)*.08;
        vec3 n,p;float t;if(playerBox(transpose(pose)*(ro-center),transpose(pose)*rd,dim*.5,t,n,p))bodyNearest=min(bodyNearest,t);
    }
    for(int i=0;i<6;i++){
        if(slot==0&&i!=0||slot==1&&(i<1||i>3)||slot==2&&i!=1&&i<4||slot==3&&i<4)continue;
        vec3 center,dim;vec2 uv,outer;playerPart(i,slim,center,dim,uv,outer);
        if(i==3){uv=vec2(40,16);}if(i>=4)uv=vec2(0,16);
        if(i==2||i==3)dim.x=4.0;
        mat3 pose=playerPitch(limbs[i]+(idle&&i>=2&&i<=3?sin(time*idleParams.y)*idleParams.x*(i==2?1.0:-1.0):0.0));
        if(idle)center.y+=sin(time*idleParams.y)*.08;
        vec3 expanded=dim+vec3(slot==2?1.0:2.0),n,p;float t;
        if(!playerBox(transpose(pose)*(ro-center),transpose(pose)*rd,expanded*.5,t,n,p)||t>=nearest||t>bodyNearest+.001)continue;
        if(i==3||i==5)p.x=-p.x;
        vec2 tex=playerUv(p*dim/expanded,n,dim,uv)/vec2(64,32);
        vec2 samplePoint=(vec2(6)+tex*36.0)/48.0;samplePoint.y=1.0-samplePoint.y;
        vec4 color=texture(atlas,samplePoint);if(color.a<.1)continue;
        nearest=t;float light=.65+.35*max(0.0,dot(pose*n,normalize(vec3(-.45,.8,1))));result=vec4(color.rgb*light,color.a);
    }
    return result;
}

layout(location = 0) out vec4 fragColor;

float random(float n) { return fract(sin(n*127.1+311.7)*43758.5453); }
// Generated protocol 4
#define DUI_SHADER_DEFINITION_BITS 6
#define DUI_SHADER_PARAMETER_BITS 240
#define DUI_SHADER_CARRIER_BITS 576
#define DUI_SHADER_MOTION_BITS 99
#define DUI_CARRIER_EFFECTS 8
#define DUI_PLAYER_SIGNATURE 14942208u
#define DUI_PLAYER_SIGNATURE_MASK 16515072u
#define DUI_PLAYER_RENDERER_BITS 4u
#define DUI_PLAYER_BAND_BITS 6u
#define DUI_PLAYER_VIEWPORT_BITS 2u
#define DUI_PLAYER_POSE_BITS 3u
#define DUI_DURATION_OFFSET 0
#define DUI_DURATION_BITS 7
#define DUI_DELAY_OFFSET 7
#define DUI_DELAY_BITS 7
#define DUI_EASING_OFFSET 14
#define DUI_EASING_BITS 2
#define DUI_ENABLED_OFFSET 16
#define DUI_ENABLED_BITS 1
#define DUI_TX_OFFSET 17
#define DUI_TX_BITS 9
#define DUI_TY_OFFSET 26
#define DUI_TY_BITS 9
#define DUI_SCALEFROM_OFFSET 35
#define DUI_SCALEFROM_BITS 8
#define DUI_SCALETO_OFFSET 43
#define DUI_SCALETO_BITS 8
#define DUI_ROTATEFROM_OFFSET 51
#define DUI_ROTATEFROM_BITS 9
#define DUI_ROTATETO_OFFSET 60
#define DUI_ROTATETO_BITS 9
#define DUI_OPACITYFROM_OFFSET 69
#define DUI_OPACITYFROM_BITS 8
#define DUI_OPACITYTO_OFFSET 77
#define DUI_OPACITYTO_BITS 8
#define DUI_PIVOTX_OFFSET 85
#define DUI_PIVOTX_BITS 8
#define DUI_PIVOTY_OFFSET 93
#define DUI_PIVOTY_BITS 8
#define DUI_BASE_DX_OFFSET 0
#define DUI_BASE_DX_BITS 11
#define DUI_BASE_DY_OFFSET 11
#define DUI_BASE_DY_BITS 11
#define DUI_BASE_SIZE_OFFSET 22
#define DUI_BASE_SIZE_BITS 7
#define DUI_BASE_EXPANDED_OFFSET 29
#define DUI_BASE_EXPANDED_BITS 1
#define DUI_HEADER_TICK_OFFSET 0
#define DUI_HEADER_TICK_BITS 15
#define DUI_HEADER_WIDTH_OFFSET 15
#define DUI_HEADER_WIDTH_BITS 9
#define DUI_HEADER_HEIGHT_OFFSET 24
#define DUI_HEADER_HEIGHT_BITS 9
#define DUI_HEADER_X_OFFSET 33
#define DUI_HEADER_X_BITS 9
#define DUI_HEADER_Y_OFFSET 42
#define DUI_HEADER_Y_BITS 9
#define DUI_HEADER_KIND_OFFSET 51
#define DUI_HEADER_KIND_BITS 3
#define DUI_CLIP_X_OFFSET 0
#define DUI_CLIP_X_BITS 10
#define DUI_CLIP_Y_OFFSET 10
#define DUI_CLIP_Y_BITS 10
#define DUI_CLIP_WIDTH_OFFSET 20
#define DUI_CLIP_WIDTH_BITS 9
#define DUI_CLIP_HEIGHT_OFFSET 29
#define DUI_CLIP_HEIGHT_BITS 9
uint duiRead(uvec3 data,int offset,int bits){int word=offset/30,shift=offset%30;uint v=data[word]>>uint(shift);if(shift+bits>30)v|=data[word+1]<<uint(30-shift);return v&((1u<<uint(bits))-1u); }

// Generic version-three shader invocation transport. No application drawing lives here.
uint duiShaderRead(int offset,int bits){
    int word=offset/30,shift=offset%30;uint value=effectWords[word/4][word%4]>>uint(shift);
    if(shift+bits>30)value|=effectWords[(word+1)/4][(word+1)%4]<<uint(30-shift);
    return value&((1u<<uint(bits))-1u);
}
float duiEase(float u,int easing){if(easing==1)return 1.0-pow(1.0-u,3.0);if(easing==2)return u*u*(3.0-2.0*u);if(easing==3){float v=u-1.0;return 1.0+2.70158*v*v*v+1.70158*v*v;}return u;}
int duiShaderSize(int code){return -1;}
vec4 duiShaderPixel(vec2 q,vec2 size,int code,int base,float t,bool live){return vec4(0);}

vec4 shaderEffects(vec2 point,float age,int flags){
    vec4 result=vec4(0);int cursor=0;bool live=(flags&8)!=0,moving=(flags&4)!=0;
    for(int i=0;i<DUI_CARRIER_EFFECTS;i++){
        if(i>=effectCount)break;
        int code=int(duiShaderRead(cursor,DUI_SHADER_DEFINITION_BITS));cursor+=DUI_SHADER_DEFINITION_BITS;
        vec2 origin=vec2(float(duiShaderRead(cursor,9)),float(duiShaderRead(cursor+9,9)));cursor+=18;
        vec2 size=vec2(float(duiShaderRead(cursor,9)),float(duiShaderRead(cursor+9,9)));cursor+=18;
        int count=duiShaderSize(code);if(count<0 || cursor+count>DUI_SHADER_CARRIER_BITS)break;
        int parameters=cursor;cursor+=count;vec2 q=point-origin;float alpha=1.0;
        if(effectKind==6){
            if(cursor+DUI_SHADER_MOTION_BITS>DUI_SHADER_CARRIER_BITS)break;
            float ticks=age*20.0-float(duiShaderRead(cursor+DUI_DELAY_OFFSET,DUI_DELAY_BITS));
            bool enabled=moving&&live&&duiShaderRead(cursor+DUI_ENABLED_OFFSET,DUI_ENABLED_BITS)!=0u;
            float u=enabled?clamp(ticks/max(1.0,float(duiShaderRead(cursor+DUI_DURATION_OFFSET,DUI_DURATION_BITS))),0.0,1.0):1.0;
            float e=duiEase(u,int(duiShaderRead(cursor+DUI_EASING_OFFSET,DUI_EASING_BITS)));
            vec2 shift=vec2(int(duiShaderRead(cursor+DUI_TX_OFFSET,DUI_TX_BITS))-256,int(duiShaderRead(cursor+DUI_TY_OFFSET,DUI_TY_BITS))-256)*(1.0-e);
            float scale=mix(float(duiShaderRead(cursor+DUI_SCALEFROM_OFFSET,DUI_SCALEFROM_BITS)),float(duiShaderRead(cursor+DUI_SCALETO_OFFSET,DUI_SCALETO_BITS)),e)/64.0;
            float angle=radians(mix(float(int(duiShaderRead(cursor+DUI_ROTATEFROM_OFFSET,DUI_ROTATEFROM_BITS))-256),float(int(duiShaderRead(cursor+DUI_ROTATETO_OFFSET,DUI_ROTATETO_BITS))-256),e));
            vec2 pivot=vec2(float(duiShaderRead(cursor+DUI_PIVOTX_OFFSET,DUI_PIVOTX_BITS)),float(duiShaderRead(cursor+DUI_PIVOTY_OFFSET,DUI_PIVOTY_BITS)))/255.0;
            alpha=mix(float(duiShaderRead(cursor+DUI_OPACITYFROM_OFFSET,DUI_OPACITYFROM_BITS)),float(duiShaderRead(cursor+DUI_OPACITYTO_OFFSET,DUI_OPACITYTO_BITS)),u)/255.0;
            if(scale<=0.0001){cursor+=DUI_SHADER_MOTION_BITS;continue;}
            q=mat2(cos(angle),-sin(angle),sin(angle),cos(angle))*(q-pivot*size-shift)/scale+pivot*size;
            cursor+=DUI_SHADER_MOTION_BITS;
        }
        // Each invocation owns its local rectangle, including after inverse motion.
        // Opaque consumer shaders must never cover adjacent components or controls.
        if(any(lessThan(q,vec2(0))) || any(greaterThanEqual(q,size)))continue;
        vec4 c=duiShaderPixel(q,size,code,parameters,moving&&live?max(0.0,age):100.0,moving&&live);c.a*=clamp(alpha,0.0,1.0);
        float a=c.a+result.a*(1.0-c.a);
        result=vec4((c.rgb*c.a+result.rgb*result.a*(1.0-c.a))/max(a,.00001),a);
    }
    return result;
}


void main() {
    if(playerArmorFlags>=0){vec4 c=playerArmorPixel(Sampler0,playerArmorPoint,playerArmorSize,playerArmorFlags,GameTime*1200.0);if(c.a<.1)discard;fragColor=c*ColorModulator;return;}
    if(effectKind==5 && (any(lessThan(clipPoint,itemClip.xy)) || any(greaterThanEqual(clipPoint,itemClip.zw))))discard;
    if(effectKind==1 || effectKind==6){vec4 panel=shaderEffects(burstPoint,burstAge,effectFlags);if(panel.a==0.0)discard;fragColor=panel*ColorModulator;return;}
    vec4 color = texture(Sampler0, texCoord0) * vertexColor;
    if (color.a == 0.0) {
        discard;
    }
    fragColor = color * ColorModulator;
}
